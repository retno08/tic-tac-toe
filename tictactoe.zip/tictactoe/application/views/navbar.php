<nav class="navbar navbar-expand-lg navbar-dark fixed-top" style="background-color:#08294a;">
      <div class="container">
  <a class="navbar-brand" href="<?php echo base_url(); ?>">
    <img src="<?php echo base_url().'assets_css/images/tictaclogo.png'?>" width="30" height="30" class="d-inline-block align-top" >
    GAME TIC TAC TOE
  </a>
  
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="<?php echo base_url(); ?>"><i class="fa fa-home"></i>
              Home
			  <span class="sr-only">(current)</span>
              </a>
            </li>
           
          </ul>
        </div>
      </div>
    </nav>