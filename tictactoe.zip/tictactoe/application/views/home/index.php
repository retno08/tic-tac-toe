<!DOCTYPE html>
<html lang="id" class="csstransforms csstransforms3d csstransitions">
<head>
    <meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	    

	<meta name="Description" content="Pembuatan aplikasi website, template dan  dapatkan tutorial mengenai web depelopment dan download berbagai library ">
	<meta name="keywords" content="portofolio retno,Framework, CSS,XML,JavaScript, PHP, jquery, nodejs, javascript, website, pembuatan website, disain website, web depelopment, web aplication, landing page, web murah, frandly code, clean code, jasa pembuatan website murah, aplikasi murah, aplikasi website murah, website murah">
    <meta name="author" content="Retno-irwansyah">
    <title>GAME TES TICTACTOE</title>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">

<link href="<?php echo base_url(); ?>assets_css/vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<link href="<?php echo base_url(); ?>assets_css/css/freelancer.min.css" rel="stylesheet" type="text/css">
<link href='http://wallpaperback.blogspot.com/favicon.ico' rel='shortcut icon'>
<!------ Include the style css tic tac toe costume ---------->
<link href="<?php echo base_url(); ?>assets_css/css/tictacstyle.css" rel="stylesheet" type="text/css">
</head>
<body>
<!-- Navigation -->
   <?php $this->load->view('navbar'); ?>
<!-- END Navigation -->

<!--  Star Konten --> 
<div class="row-fluid main-section text-center">
<div class="container">
<h1 class="span3">Tic Tac Toe</h1>
<div class="span3">
    <div class="input-prepend input-append">
    <span class="add-on win_text">O won</span><strong id="o_win" class="win_times add-on"> 0</strong><span class="add-on"> time(s)</span>
    </div>
    <div class="input-prepend input-append">
    <span class="add-on win_text">X won</span><strong id="x_win" class="win_times add-on"> 0</strong><span class="add-on"> time(s)</span>
    </div>    
</div>  

<div  id="game">
<li id="one"  width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1" >+</li>
<li id="two"  width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
<li id="three" width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
</div>
<div  id="game">
<li id="four"  width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
<li id="five"  width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
<li id="six"   width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
</div>
<div  id="game">
<li id="seven" width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
<li id="eight" width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
<li id="nine"  width="150" height="150" style="border:5px solid white; background-color:gray" class="btn span1">+</li>
</div>



<div class="clr">&nbsp;</div><br>
<button type="button" id="reset"  class="btn btn-outline-success btn-lg">Restart</button>
</div>

</div>
<!--  End Konten --> 

<!--  Start Footer --> 
<footer class="section footer-classic context-dark bg-image" style="background: #000518;">
        <div class="container">
          <div class="row row-30">
            <div class="col-md-4 col-xl-5">
			<br>
              <div class="pr-xl-4">
                <p>Hai !! Saya Retno Irwansyah,<br>kami melayani design web, google advertising, fb advertising,  design, pembuatan aplikasi skripsi, account google adsense, premium template blog & wordpress.</p>
                <!-- Rights-->
                <p class="rights"><span>Template ©  </span><span class="copyright-year">2018</span><span> </span><span>Retno Irwansyah</span><span>. </span><br><span>Hak Cipta Dilindungi.</span></p>
              </div>
            </div>
            <div class="col-md-4">
			<br>
              <h5>Contac</h5>
              <dl class="contact-list">
                <dt>Address:</dt>
                <dd>JL. Kenanga 2 Lintas RT. 008, LLG</dd>
              </dl>
              <dl class="contact-list">
                <dt>email:</dt>
                <dd><a href="mailto:#">Retnoirwansyah08@gmail.com</a></dd>
              </dl>
              <dl class="contact-list">
                <dt>phone:</dt>
                <dd><a href="tel:#">+62 81996242734</a> 
                </dd>
              </dl>
            </div>
            <div class="col-md-4 col-xl-3">
			<br>
              <h5>Pengembangan</h5>
              <ul class="nav-list">
                <li><a href="#">Dokumentasi</a></li>
                <li><a href="#">Blog Tutorial</a></li>
                <li><a href="#">Solusi</a></li>
                <li><a href="#">Hubungi Kami</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="row no-gutters social-container">
          <div class="col"><a class="social-inner" href="fb.com"><span><i class="fab fa-facebook"> Facebook</i></span></a></div>
          <div class="col"><a class="social-inner" href="instagram.com"><span><i class="fab fa-instagram"> Instagram</i></span></a></div>
          <div class="col"><a class="social-inner" href="linkedin.com"><span><i class="fab fa-linkedin"> Linkedin</i></span></a></div>
         
        </div>
      </footer>
<!--  End Footer --> 



<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!-- Custom scripts for this template -->
<script type="text/javascript" src="<?php echo base_url().'assets_css/vendor/bootstrap/js/bootstrap.bundle.min.js'?>"></script>
<!-- scripts JS Tic Tac Toe -->
<script type="text/javascript" src="<?php echo base_url().'assets_css/js/tictactoe.min.js'?>"></script>

</body>
</html>